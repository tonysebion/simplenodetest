﻿function enableAccordionControls() {
    if ($(".accordion").length) {
        $(".accordion > li > a").click(function () {
            $(this).parent().toggleClass("active", 200);
            $(".accordion > li").not($(this).parent()).removeClass("active", 200);
        });
    }
}

function enableSearchControls() {
    $("#Search").autocomplete({
        source: "/Pages/SearchTerms.ashx",
        minLength: 2
    });
    $("#Search").keypress(function (e) {
        if (e.which === 13) {
            $("#GlobalSiteSearchButton").trigger("click");
            return !1
        }
    })
}

function enableExpandableContentControls() {
    $(".ExpandContentTrigger a").click(function () {
        $(this).parent().toggleClass("active", 200);
        $(this).parent().next(".ExpandedContent").toggleClass("active", 200);
    });
}

function showExitModal(show) {
    var overlay = $(".exitModal.ModalOverlay");
    var modal = $(".exitModal.ModalWindow");

    if (show) {
        overlay.css("left", "0");
        overlay.css("display", "block");
        modal.css("zIndex", "4");
        modal.css("display", "block");
        $(".exitModal.Modal-OKbutton").focus();
        resizeExitModal(overlay, modal);
    } else {
        overlay.css("display", "none");
        modal.css("display", "none");
    }
}

function resizeExitModal(overlay, modal) {
    if ("block" === overlay.css("display")) {
        overlay.css("height", window.getComputedStyle(document.documentElement).height);
        var modalRect = modal[0].getBoundingClientRect();
        var t = (window.getComputedStyle(document.documentElement),
            (window.innerHeight - parseInt(modalRect.height)) / 2 + window.scrollY + "px");
        var n = (window.innerWidth - parseInt(modalRect.width)) / 2 + window.pageXOffset + "px";
        modal.css("top", t);
        modal.css("left", n);
    }
}

function processExternalLinks() {
    var exemptUrls = [".mil", ".gov", "addtoany.com", "corp-ws.wpsic.com", "express-scripts.com", "hnfs.net", "humana-military.com", "infocenter.humana-military.com", "www.mytricare.com", "secure.ucci.com", "trdp.org", "tricareformularysearch.org", "tricareonline.com", "triwest.com"];

    $("a").each(function () {
        var host = this.hostname.toLowerCase();
        if (0 !== host.length && host !== location.hostname) {
            for (var n = 0; n < exemptUrls.length; n++) {
                if (host.indexOf(exemptUrls[n]) > -1)
                    return;
            }
            $(this).click(function (e) {
                e.preventDefault();
                e.stopPropagation();
                var href = $(this).attr("href");
                $(".exitModal.Modal-OKbutton").click(function () {
                    window.open(href, "_blank");
                    showExitModal(false);
                });
                $(".exitModal.Modal-OKbutton").keydown(function (ev) {
                    9 != ev.keyCode || ev.shiftKey || (ev.preventDefault(),
                        $(".exitModal.Modal-Cancelbutton").focus()),
                        27 === ev.keyCode && showExitModal(false)
                });

                showExitModal(true);

                $(".exitModal.Modal-OKbutton").focus();
                return !1;
            });
        }
    });

    $(window).on('resize', function () {
        resizeExitModal($(".exitModal.ModalOverlay"), $(".exitModal.ModalWindow"));
    });

    $(".exitModal.Modal-Cancelbutton").click(function () {
        showExitModal(false);
    });

    $(".exitModal.Modal-Cancelbutton").keydown(function (e) {
        9 != e.keyCode || e.shiftKey || (e.preventDefault(),
            $(".exitModal.Modal-OKbutton").focus()),
            27 === e.keyCode && showExitModal(false)
    });

}

$(document).ready(function () {
    processExternalLinks();
});
