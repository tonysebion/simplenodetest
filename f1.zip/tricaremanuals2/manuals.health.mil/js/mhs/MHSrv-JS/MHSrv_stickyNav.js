(function () {

    //console.log("MHSrv_stickyNav.js loaded");

    const header = document.getElementsByTagName("header")[0];
    const mainNav = document.getElementById("MainNav");
    const mobileNav = document.getElementById("mobileNav");

    let top = header.getBoundingClientRect().top;
    let bottom = header.getBoundingClientRect().bottom;
    let height = header.getBoundingClientRect().height;
    let isStuck = false;

    let headerHeight = 0;

    let rec = header.getBoundingClientRect(); // get header rectabngle
    let rec2 = header.parentNode.getBoundingClientRect(); // get parent (body) rectangle

    let lastY = 0; // used for checking scroll direction
    let downY = 0; // used for checking scroll UP distance
    let threshold = 0; // used for checking scroll UP distance
    let navClickTop = 0;


    window.onscroll = function () { makeSticky() };

    function makeSticky() {
        let currentY = window.pageYOffset;
        let scrollDown = lastY < currentY;

        let style = getComputedStyle(mainNav);
        let display = style.display;

        if (display == "none") { // if main navigation is NOT displayed (is small screen)
            if (scrollDown) {
                if (!mobileNav.classList.contains('open')) {

                    downY = currentY;
                    if (currentY >= bottom && !mobileNav.classList.contains("open")) {
                        header.classList.add("offscreen");
                        header.classList.remove("sticky");
                        header.style.top = "";
                        headerHeight = 0;
                    }
                }
            } else {
                // on scroll up... 
                if (!mobileNav.classList.contains('open')) {

                    if (currentY <= 10) {
                        header.classList.remove("sticky");
                        header.classList.remove("offscreen");
                        header.style.top = "";
                        headerHeight = 0;
                    } else if ((currentY + threshold) < downY) {
                        if (!header.classList.contains("sticky")) {
                            header.classList.remove("offscreen");
                            header.classList.add("sticky");
                        }

                        let box = header.getBoundingClientRect();
                        headerHeight = box.height;
                    }
                }
            }
        } else {
            headerHeight = 0;
        }

        let mobileStyle = getComputedStyle(mobileNav);
        let mobileDisplay = mobileStyle.display;

        if (mobileDisplay == "none") {
            header.classList.remove("offscreen");
            header.classList.remove("sticky");
            document.body.classList.remove('no-scroll');
        }

        lastY = currentY;
    }

})();