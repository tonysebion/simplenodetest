
    //console.log("MHSrv_mobileMenu.js loaded");

    const mainNav = document.getElementsByTagName('nav')[0];
    const footer = document.getElementsByTagName('footer')[0];
    //const footer = document.getElementById('footerPopupNav');

    const navListenerAttached = false;
    const footerListenerAttached = false;

    const menuTrigger = document.querySelector("#mobileNav-btn");
    const menu = document.querySelector(".mobileNav");
    const wrapper = document.querySelector(".mobileNav-wrapper");
    const darkDiv = document.getElementById("darkDiv");

    menuTrigger.addEventListener("click", function () {
        let expanded = this.getAttribute("aria-expanded");
        toggleMobileMenu(expanded);
    });

    // open / close mobile menu
    function toggleMobileMenu(ex) {
        let expanded = ex;

        if (expanded == "false" && !menu.classList.contains("open")) {
            openMenu();
        } else {
            closeMenu();
        }
    }

    // open / close functions 
    function openMenu() {
        menuTrigger.setAttribute("aria-expanded", "true");
        menu.setAttribute("aria-hidden", "false");
        menu.classList.add("open");
        darkDiv.classList.add("overlay");
        document.body.classList.add("no-scroll");
    }

    function closeMenu() {
        menuTrigger.setAttribute("aria-expanded", "false");
        menu.setAttribute("aria-hidden", "true");
        menu.classList.remove("open");
        darkDiv.classList.remove("overlay");
        document.body.classList.remove("no-scroll");
    }

    // click outside of menu to close it 
    document.addEventListener('mouseup', function (e) {
        if (!wrapper.contains(e.target)) {
            closeMenu();
        }
    });

    // tab out of mobile menu to close it 
    document.addEventListener('keyup', function (e) {
        if (!wrapper.contains(e.target)) {
            closeMenu();
        }
    });

    //function focusNav(tab) {
    //    let container = tab.parentElement.parentElement;
    //    let upOne = container.parentElement.parentElement;
    //    if (upOne === mainNav) {
    //        removeFocus();
    //        container.classList.add('focus');
    //    }
    //}

    //function removeFocus() {
    //    let oldFocus = mainNav.getElementsByClassName("focus")[0];
    //    if (oldFocus !== undefined && oldFocus !== null) oldFocus.classList.remove('focus');
    //    oldFocus = footer.getElementsByClassName("focus")[0];
    //    if (oldFocus !== undefined && oldFocus !== null) oldFocus.classList.remove('focus');
    //}

    //function clearNavFocusOnBlur(e) {
    //    if (navListenerAttached && !mainNav.contains(e.target)) {
    //        removeFocus();
    //        document.removeEventListener("focusin", clearNavFocusOnBlur);
    //        navListenerAttached = false;
    //    }
    //}

    //function addNavListener() {
    //    if (!navListenerAttached) {
    //        document.addEventListener("focusin", clearNavFocusOnBlur);
    //        navListenerAttached = true;
    //    }
    //}

    //function focusFooter(tab) {
    //    let container = tab.closest('li'); // parent li
    //    let upTwo = container.parentElement.parentElement;
    //    if (upTwo === footer) {
    //        removeFocus();
    //        container.classList.add('focus');
    //    }
    //}

    //function clearFooterFocusOnBlur(e) {
    //    if (footerListenerAttached && !footer.contains(e.target)) {
    //        removeFocus();
    //        document.removeEventListener("focusin", clearFooterFocusOnBlur);
    //        footerListenerAttached = false;
    //    }
    //}

    //function addFooterListener() {
    //    if (!footerListenerAttached) {
    //        document.addEventListener("focusin", clearFooterFocusOnBlur);
    //        footerListenerAttached = true;
    //    }
    //}


    function keyupNav(event, tab) {
        if (event.keyCode == '56') { // * (asterisk)
            // Expands all closed sibling nodes that are at the same level as the focused node.
            // Focus does not move.

            var siblings = tab.parentElement.parentElement.querySelector("ul").children;
            for (i = 0; i < siblings.length - 1; i++) {
                if (siblings[i].classList.contains("hasChildren") && !(siblings[i].classList.contains("active"))) {
                    var iconSpan = siblings[i].querySelector("span.icon");
                    var iconSpanOnclicAttr = siblings[i].querySelector("span.icon").getAttribute("onclick");
                    var iconSplit = siblings[i].querySelector("span.icon").getAttribute("onclick").split(",")
                    ShowSubmenu(iconSpan, parseInt(iconSplit[1]), iconSplit[2].replace(/'/g, "").replace(")", ""));
                    event.stopPropagation();
                }
            }

            event.stopPropagation();
        }
    }

    function keypressNav(event, tab) {
        /* 
                 This function and related ones developed from the W3C guidelines specified here:
                 https://www.w3.org/TR/wai-aria-practices/examples/treeview/treeview-2/treeview-2a.html
        */

        //first reroute focus to the list element      
        if (tab.nodeName == "A" && event.keyCode != 9) {
            tab.parentElement.parentElement.focus();
            tab = tab.parentElement.parentElement;
        }

        let characterCode = event.keyCode;
        //console.log('%ckeypressNav(event, tab)', 'color: yellow; font-weight: bold;');

        switch (true) {

            case characterCode == 39: // Arrow Right
                //console.log("39 - Arrow Right");

                /*
                    When focus is on a closed node, opens the node; focus does not move.
                    When focus is on a open node, moves focus to the first child node.
                    When focus is on an end node, does nothing.
                */

                event.preventDefault();

                // check if there are children and if they haven't been expanded, expand them while keeping focus on the tab 
                if (tab.classList.contains("hasChildren") && !(tab.classList.contains("active"))) {
                    //var iconSpan = tab.querySelector("span.icon");
                    //var iconSpanOnclicAttr = tab.querySelector("span.icon").getAttribute("onclick");
                    //var iconSplit = tab.querySelector("span.icon").getAttribute("onclick").split(",")
                    //ShowSubmenu(iconSpan, parseInt(iconSplit[1]), iconSplit[2].replace(/'/g, "").replace(")", ""));
                    let btn = tab.getElementsByTagName("button")[0];
                    ShowSubmenu(btn);
                }
                // if the tab already has its children expanded, go to the first child
                else if (tab.classList.contains("hasChildren") && tab.classList.contains("active")) {
                    //switchFocus(event, tab, tab.querySelector("ul").querySelector("li"));
                    switchFocus(event, tab, tab.getElementsByTagName("ul")[0].getElementsByTagName("li")[0]);
                }
                break;

            case characterCode == 37: // Arrow Left
                //console.log("37 - Arrow Left");

                /*
                When focus is on an open node, closes the node.
                When focus is on a child node that is also either an end node or a closed node, moves focus to its parent node.
                When focus is on a root node that is also either an end node or a closed node, does nothing.
                */

                event.preventDefault();

                // if at the a node that has displayed childen close it:
                if (tab.classList.contains("hasChildren") && (tab.classList.contains("active"))) {
                    tab.querySelector("button").click();
                }
                // otherwise go up the parent node - if it's in the tree
                else if (tab.parentElement.parentElement.nodeName == "LI") {
                    switchFocus(event, tab, tab.parentElement.parentElement);
                }
                break;

            case characterCode == 40: // Arrow Down
                //console.log("40 - Arrow Down");

                /*
                    Moves focus to the next node that is focusable without opening or closing a node.
                    If focus is on the last node, does nothing.
                */

                event.preventDefault();

                // if the current tab has expanded children, then go to the first child
                if (tab.querySelectorAll("ul.subMenu").length > 0 && tab.classList.contains("active")) {
                    switchFocus(event, tab, tab.querySelectorAll("ul.subMenu")[0].querySelectorAll("li")[0]);
                }
                // otherwise, check if this is the last on the current level and if not, go to the next tab (sibling)
                else if (tab.nextElementSibling != null) {
                    switchFocus(event, tab, tab.nextElementSibling);
                }
                // this is the last sibling so check if there is a next sibling of the parent element
                else if (tab.parentElement.parentElement.nextElementSibling != null) {
                    switchFocus(event, tab, tab.parentElement.parentElement.nextElementSibling);
                }
                break;

            case characterCode == 38: // Arrow Up
                //console.log("38 - Arrow Up");

                /*
                    Moves focus to the previous node that is focusable without opening or closing a node.
                    If focus is on the first node, does nothing.
                */

                event.preventDefault();

                //tab has a previous sibling on same level
                if (tab.previousElementSibling != null && tab.previousElementSibling.nodeName == "LI") {
                    // if that previous sibling has an expanded list of submenu items, go to the last one:
                    if (tab.previousElementSibling.classList.contains("hasChildren") && tab.previousElementSibling.classList.contains("active")) {
                        //get the last item of the previous sibling
                        var lastNiece = tab.previousElementSibling.querySelectorAll("ul.subMenu")[tab.previousElementSibling.querySelectorAll("ul.subMenu").length - 1].querySelectorAll("li")[tab.previousElementSibling.querySelectorAll("ul.subMenu")[tab.previousElementSibling.querySelectorAll("ul.subMenu").length - 1].querySelectorAll("li").length - 1];
                        switchFocus(event, tab, lastNiece);
                    }
                    // otherwise just go to the previous sibling
                    else {
                        switchFocus(event, tab, tab.previousElementSibling);
                    }
                }
                // otherwise if the parent is still a tab (not the nav element) then go to it:
                else if (tab.parentElement.parentElement.nodeName == "LI") {
                    switchFocus(event, tab, tab.parentElement.parentElement);
                }
                break;

            case characterCode == 13: // Enter
                //console.log("13 - Enter");
            case characterCode == 32: // Space
                //console.log("32 - Space");
                /* 
                 Performs the default action (e.g. onclick event) for the focused node.
                 In this example, the default action is to activate the link, opening its target page.
                 */

                event.preventDefault();

                // if the tab has children, expand them
                if (tab.classList.contains("hasChildren") && !(tab.classList.contains("active"))) {
                    //var iconSpan = tab.querySelector("span.icon");
                    //var iconSpanOnclicAttr = tab.querySelector("span.icon").getAttribute("onclick");
                    //var iconSplit = tab.querySelector("span.icon").getAttribute("onclick").split(",")
                    //ShowSubmenu(iconSpan, parseInt(iconSplit[1]), iconSplit[2].replace(/'/g, "").replace(")", ""));
                    let btn = tab.querySelector("button");
                    ShowSubmenu(btn);
                }
                // otherwise active the link
                else {
                    tab.querySelector("a").click();
                }
                break;

            case characterCode == 36: // Home
                //console.log("36 - Home");

                //Moves focus to first node without opening or closing a node.

                event.preventDefault();

                // Moves focus to first node without opening or closing a node.
                var firstTab = tab.closest("nav > ul").querySelector("li");
                switchFocus(event, tab, firstTab);
                break;

            case characterCode == 35: // End
                //console.log("35 - End");

                // Moves focus to the last node that can be focused without expanding any nodes that are closed.

                event.preventDefault();

                // first get the last level one tab, which we know is the place to start looking:
                var LV1Tabs = tab.closest("nav > ul.LV1").children;
                var lastLV1Root = LV1Tabs[LV1Tabs.length - 1];
                var lastTab = lastLV1Root;

                // Goes three levels deep, probably should be rewritten as a recursive function 
                if (lastLV1Root.classList.contains("hasChildren") && lastLV1Root.classList.contains("active")) {
                    var LV2Tabs = lastLV1Root.querySelector("ul.LV2").children;
                    var lastLV2Root = LV2Tabs[LV2Tabs.length - 1];
                    lastTab = lastLV2Root;

                    if (lastLV2Root.classList.contains("hasChildren") && lastLV2Root.classList.contains("active")) {
                        var LV3Tabs = lastLV2Root.querySelector("ul.LV3").children;
                        var lastLV3Root = LV3Tabs[LV3Tabs.length - 1];
                        lastTab = lastLV3Root;

                        if (lastLV3Root.classList.contains("hasChildren") && lastLV3Root.classList.contains("active")) {
                            var LV4Tabs = lastLV3Root.querySelector("ul.LV4").children;
                            var lastLV3Root = LV4Tabs[LV4Tabs.length - 1];
                            lastTab = lastLV4Root;
                        }
                    }
                }

                switchFocus(event, tab, lastTab);

                break;

            case (characterCode > 64 && characterCode < 91) || (characterCode > 96 && characterCode < 123): //a-z, A-Z
                //console.log("codes - a-z / A-Z");

                /*
                    Focus moves to the next node with a name that starts with the typed character.
                    Search wraps to first node (that matches - ie previous nodes) if a matching name is not found among the nodes that follow the focused node.
                    Search ignores nodes that are descendants of closed nodes.
                 */

                event.preventDefault();

                // create an array of li's:
                var tabs = tab.closest("nav").querySelectorAll("li");
                // now remove those that aren't visible:
                for (i = 0; i < tabs.length - 1; i++) {
                    if (tabs[i].parentElement.classList.contains("LV1") || (tabs[i].parentElement.parentElement.classList.contains("hasChildren") && tabs[i].parentElement.parentElement.classList.contains("active"))) {
                        tabs[i].classList.add("visbl");
                    }
                }
                // now loop through the new list and when we get to the current tab, start checking for matches
                var afterTab = false;
                var visibleTabs = tab.closest("nav").querySelectorAll("li.visbl");

                for (i = 0; i < visibleTabs.length - 1; i++) {
                    if (tab == visibleTabs[i]) {
                        afterTab = true;
                    }
                    if (afterTab == true && visibleTabs[i + 1] != null) {
                        if (checkForMatch(event.key, visibleTabs[i + 1])) {
                            switchFocus(event, tab, visibleTabs[i + 1]);
                            event.stopPropagation();
                            return false;
                            break;
                        }
                    }
                }

                // if no tab beginning with the appropriate letter has been found AFTER the focused tab, go back and check starting at the first visible tab:
                for (i = 0; i < visibleTabs.length - 1; i++) {
                    if (visibleTabs[i + 1] != null) {
                        if (checkForMatch(event.key, visibleTabs[i + 1])) {
                            switchFocus(event, tab, visibleTabs[i + 1]);
                            event.stopPropagation();
                            return false;
                            break;
                        }
                    }
                }
                break;
        }
        event.stopPropagation();
    }

    let currentNavFocus;

    function ShowSubmenu(buttonNode, level, itemid) {
        let li = buttonNode.parentNode.parentNode;

        // get id of corresponding ul with button's aria-contol value
        let controls = buttonNode.getAttribute("aria-controls");

        // if button is already 'open'
        if (li.classList.contains("active")) {
            // remove active class from parent to close it
            li.classList.remove("active");
            li.setAttribute("aria-expanded", "false");
            let openChildren = li.getElementsByClassName("active");
            for (let i = openChildren.length - 1; i >= 0; i--) {
                openChildren.item(i).classList.remove("active");
            }
            //remove visbl class for all children
            let liChildren = li.querySelectorAll("li");
            for (let i = 0; i < liChildren.length - 1; i++) {
                liChildren[i].classList.remove("visbl");
            }
        }
        else {
            // if subMenu is already on the page just show it
            li.setAttribute("aria-expanded", "true");
            li.classList.add("active");

            if (li.lastElementChild.nodeName == "UL") {
                li.classList.add("active");
            }
            else {
                // else request it and render it
                let xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {
                    if (this.readyState == 4 && this.status == 200) {
                        li.classList.add("active");
                        li.insertAdjacentHTML("beforeend", this.responseText);
                    }
                }
                xhttp.open("GET", "/MHSMvc/Navigation/Submenu?level=" + level + "&itemId=" + itemid, true);
                xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhttp.send();
            }
        }

    }

    function switchFocus(event, focusFrom, focusTo) {
        focusFrom.setAttribute("tabindex", "-1");
        focusTo.setAttribute("tabindex", "0");

        focusFrom.classList.remove("focus");
        focusTo.classList.add("focus");
        focusTo.focus();
        event.stopPropagation();
    }

    function checkForMatch(keyTyped, firstCharOfTab) {
        if (firstCharOfTab.querySelector("div").textContent.trim().toUpperCase().charAt(0) == keyTyped.toUpperCase()) {
            return true;
        }
        return false;
    }
    //tabindex stuff
    //document.addEventListener("DOMContentLoaded", function () {
    //    var leftNav = document.getElementById("leftNav");
    //    if (leftNav == null) return;
    //    var activeNode = leftNav.getElementsByClassName("currentArrow"); // this is a span
    //    // activeNode.parentNode.parentNode would be the <li>
    //});

