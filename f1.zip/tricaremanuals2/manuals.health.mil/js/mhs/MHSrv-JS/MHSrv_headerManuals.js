// this file is mostly for megamenu functionality 

(function () {

    //console.log("MHSrv_header.js loaded!");

    const header = document.getElementsByTagName("header")[0];
    const mainNav = document.querySelector("#MainNav");
    const ul = mainNav.firstElementChild;
    const triggerBtns = document.getElementsByClassName("trigger-btn");
    const megaMenus = document.getElementsByClassName("megaMenu-wrapper");
    const dropdowns = document.getElementsByClassName("megaMenu-dropdown");
    let darkDiv = document.querySelector("#darkDiv");
    let autoCompleteTag = null;

    let menuOpen;

    const longValChangeHistory = document.getElementById("ChangeHistory").children[0].textContent;
    const longValManualsByDate = document.getElementById("ManualsByDate").children[0].textContent;

    // shorten mainNav link text on window resize
    // & assist with right alignment of I Want To... mega menu
    function resize() {
        let width = window.innerWidth;
        let changeHistoryLink = document.getElementById("ChangeHistory").children[0];
        let manualsByDateLink = document.getElementById("ManualsByDate").children[0];

        if (width <= 1220) {
            changeHistoryLink.textContent = "History";
            manualsByDateLink.textContent = "By Date";
        } else {
            changeHistoryLink.textContent = longValChangeHistory;
            manualsByDateLink.textContent = longValManualsByDate;
        }

        // when window starts using full "desktop" nav, remove darkdiv functionality
        //if (width >= 820) {
        //    darkDiv.classList.remove("overlay");
        //}

    }

    resize();

    window.onresize = resize;

    // reset mega menus / trigger btns & dropdown <li>
    function reset() {

        for (const menu of megaMenus) {
            menu.setAttribute("aria-hidden", "true");
            menu.classList.remove("open");
        }
        for (const btn of triggerBtns) {
            btn.setAttribute("aria-expanded", "false");
        }
        for (const li of dropdowns) {
            li.classList.remove("active");
        }
        menuOpen = false;
    }

    reset();

    function openMenu(btn) {

        // get aria-control value from btn
        let ctrl = btn.getAttribute("aria-controls");
        // get megaMenu-wrapper based on val 
        let wrap = document.getElementById(ctrl);
        // get associated li.dropdown 
        let li = wrap.parentElement;

        btn.setAttribute("aria-expanded", "true");
        wrap.setAttribute("aria-hidden", "false");
        wrap.classList.add("open");
        li.classList.add("active");
        menuOpen = true;
    }

    function closeMenu(btn) {

        // get aria-control value from btn
        let ctrl = btn.getAttribute("aria-controls");
        // get megaMenu-wrapper based on val 
        let wrap = document.getElementById(ctrl);
        // get associated li.dropdown 
        let li = wrap.parentElement;

        btn.setAttribute("aria-expanded", "false");
        wrap.setAttribute("aria-hidden", "true");
        wrap.classList.remove("open");
        li.classList.remove("active");
        menuOpen = false;
    }

    function toggleMenu(btn) {

        let expanded = btn.getAttribute("aria-expanded");
        if (expanded === "true") {
            // if menu associated with trigger button is open, close it
            closeMenu(btn);
        } else {
            // if different trigget btn is clicked...
            reset();
            openMenu(btn);
        }

    }

    for (const btn of triggerBtns) {
        btn.addEventListener("click", function (e) {
            e.preventDefault();
            toggleMenu(btn);
        });
        btn.addEventListener("mouseover", function () {
            if (menuOpen) {
                reset();
            }
            openMenu(btn);
        });
        btn.addEventListener("focus", function () {
            let expand = btn.getAttribute("aria-expanded");
            if (expand === "false") {
                openMenu(btn);
            }
        });
        btn.addEventListener("blur", function () {

        });

    }

    for (const li of dropdowns) {
        if (!li.firstElementChild.classList.contains("search")) {
            li.firstElementChild.addEventListener("focus", function () { reset(); });
        }
    }

    // tab out of any mega menus (search) to close all
    document.addEventListener('keyup', function (e) {
        if (!mainNav.contains(e.target)) {
            reset();
        }
        if (document.getElementById("txtSiteSearch") == document.activeElement && e.keyCode == 13) {
            document.getElementById("btnSearch").click();
        }
    });

    // click out of mega menu to close it 
    document.addEventListener('mouseup', function (e) {
        let target = e.target;
        let mobileMenu = document.getElementById("mobileNav");
        if (!mobileMenu.contains(target)) {
            for (const btn of triggerBtns) {
                let ex = btn.getAttribute("aria-expanded");
                let val = btn.getAttribute("aria-controls");
                let el = document.getElementById(val);
                if (ex === "true" && !el.contains(target)) {
                    reset();
                    break;
                }
            }
        }
        
    });

})();
